import discord
import os
import requests
import json
import random

client = discord.Client()

gambit_words = ["gambit", "Gambit", "Start", "Round"]
coin_trick = [
"All right, mavericks! Ready to see what you're fightin' today?",
"All right, all right, all right. Let's see what we've got.",
"Enough foolin' around.",
"Oooh!",
"Ding, Ding, Ding, Ding, Ding!"
]
enemy_type = [
"Fallen on the horizon!",
"Hive! Bring a sword.",
"Vex on the field!",
"Cabal on the field!",
"Scorn approaching!"
]
prep_phase = [
"Yeah, I was at Twilight Gap. My grandma, too. Who wasn't? Shoot some Fallen!",
"Fallen. ...I'd go out there with ya, but I pawned my Gjallarhorn. Shucks.",
"Ever hear of a Fallen, name of Variks the Loyal? If he's so loyal, where's he now?",
"Ever been up to the Leviathan? Cabal can be a HOOT! Still gotta fight'em.",
"If I were here when Ghaul took the Tower? I woulda waited for you to do you, brother.",
"Cabal culture is all military these days. Used to be they were easier to kill.",
"You, me, and the crew oughta loot the Cabal Emperor's athenaeum worlds.",
"The Cabal shield can plate your starship. Or be your coffee table. ",
"You can burn Hive guts for a fire in the wild. It's toasty!",
"You ever have to fight a Thrall barehanded, you grab the skull and squeeze.",
"It takes about a hundred of Shaxx's Redjacks to take down a Hive Knight. Why does he bother building 'em?",
"I like to set Hive on fire to hear the crackle and pop.",
"Think you can eat a Hive Knight? Those're the questions you ask yourself on the frontier.",
"Ever pull a gun off a Vex arm? Don't bother. It won't shoot anymore.",
"All that bleeding-edge tech and the Vex use it to simulate junk. Such a waste.",
"Vex have that soft spot at the center. Bet you could cook that - eat it.",
"Never trust a Scorn! They're little balls of instinct. Shoot first, talk to it later.",
"I don't scare, but when it comes to the Scorn...I bring an extra gun just in case.",
"Mark my words. One day I will find the courage to eat a whole Scorn.",
"Dark Ether in Scorn can't be controlled. Not even with Motes. Get rid of 'em.",
"Motes of Dark have no effect on Scorn - not even with all that cursed Ether inside.",
"The Scorn depress me just by existing. Look at 'em. Ugh.",
"Scorn have no endgame. Nothing to lose. I can relate.",
"I've dealt with ugly, but damn! Scorn are UGLY! Finish this fast, yeah?",
"Cayde's dead, and I need more guns, one step forward, one step back.",
"Welcome aboard.",
"Welcome to Gambit." 
]
transmat_firing = [
"Prepare for transmat!",
"Get ready for transmat!",
"Transmat is go!",
"Transmat is firing!"
]

@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    msg = message.content

    if message.content.startswith('$hello'):
        await message.channel.send('Hello!')
    
    if message.content.startswith('$dredgen'):
        await message.channel.send('Hey, hey! Youre a Dredgen! Fight like one, Brotha')

    if message.content.startswith('$gambit'):
      await message.channel.send(random.choice(coin_trick))
      await message.channel.send(random.choice(enemy_type))
      await message.channel.send(random.choice(prep_phase))
      await message.channel.send(random.choice(transmat_firing))

client.run(os.getenv('TOKEN'))
